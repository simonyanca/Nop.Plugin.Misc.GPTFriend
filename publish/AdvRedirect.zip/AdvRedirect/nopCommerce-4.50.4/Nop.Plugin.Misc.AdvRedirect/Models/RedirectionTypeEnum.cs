﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.AdvRedirect.Models
{
    public enum RedirectionTypeEnum
    {
        Match, RegularExpresion
    }
}
